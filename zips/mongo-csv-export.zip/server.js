const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const cors = require('cors');
const path = require('path');
const util = require('util');
const archiver = require('archiver'); // For zipping multiple CSVs

// 1. Your connection string
const uri = 'Your connection string';
const client = new MongoClient(uri);

const app = express();
app.use(cors());
app.use(express.json());

// Optional: serve a simple index.html if you like
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

/**
 * Utility: Flatten nested objects/arrays into dot-notation, EXCEPT we keep _id as a single field.
 * That means we treat doc._id specially (convert to a string if needed) and do NOT flatten it.
 */
function flattenDoc(doc, parentKey = '', res = {}) {
  // Special handling for top-level _id
  if (!parentKey && doc.hasOwnProperty('_id')) {
    // If it's an ObjectId, convert to its 24-char hex string
    if (doc._id && doc._id._bsontype === 'ObjectId') {
      res['_id'] = doc._id.toHexString();
    }
    // If it's a Buffer or BinData, turn it into a hex string (or whatever format you need)
    else if (Buffer.isBuffer(doc._id)) {
      res['_id'] = doc._id.toString('hex');
    }
    // Otherwise just store as-is
    else {
      res['_id'] = doc._id;
    }
    // Remove it so we don't accidentally flatten it below
    delete doc._id;
  }

  // Now flatten the rest
  if (Array.isArray(doc)) {
    doc.forEach((value, index) => {
      const newKey = parentKey ? `${parentKey}.${index}` : String(index);
      flattenDoc(value, newKey, res);
    });
  } else if (doc && typeof doc === 'object') {
    for (const [key, value] of Object.entries(doc)) {
      const newKey = parentKey ? `${parentKey}.${key}` : key;
      flattenDoc(value, newKey, res);
    }
  } else {
    // It's a primitive value
    if (parentKey) {
      res[parentKey] = doc;
    }
  }
  return res;
}

/** GET /api/databases -> list all DBs */
app.get('/api/databases', async (req, res) => {
  try {
    await client.connect();
    const adminDb = client.db().admin();
    const dbsInfo = await adminDb.listDatabases();
    res.json({ databases: dbsInfo.databases.map((d) => d.name) });
  } catch (err) {
    console.error('Error listing DBs:', err);
    res.status(500).json({ error: 'Failed to list DBs' });
  }
});

/** GET /api/databases/:dbName/collections -> list all collections in the DB */
app.get('/api/databases/:dbName/collections', async (req, res) => {
  const { dbName } = req.params;
  try {
    await client.connect();
    const db = client.db(dbName);
    const collections = await db.listCollections().toArray();
    res.json({ collections: collections.map((c) => c.name) });
  } catch (err) {
    console.error('Error listing collections:', err);
    res.status(500).json({ error: 'Failed to list collections' });
  }
});

/**
 * GET /api/databases/:dbName/export/:collName
 * - Exports the specified collection as CSV
 * - Flatten everything EXCEPT `_id`, which is replaced with a single `_id` column
 * - Standard CSV: header row first, then data rows
 */
app.get('/api/databases/:dbName/export/:collName', async (req, res) => {
  const { dbName, collName } = req.params;
  try {
    await client.connect();
    const db = client.db(dbName);
    const collection = db.collection(collName);

    // 1) Get all docs
    const docs = await collection.find({}).toArray();

    // 2) Flatten each doc, track union of columns
    const flattenedDocs = [];
    const allColumns = new Set();

    for (const doc of docs) {
      const flat = flattenDoc(doc);
      flattenedDocs.push(flat);
      Object.keys(flat).forEach((k) => allColumns.add(k));
    }

    // 3) Sort columns (header)
    const sortedCols = Array.from(allColumns).sort();

    // 4) Build CSV
    //    a) header row
    let csv = sortedCols.join(',') + '\n';

    //    b) each doc row
    for (const fdoc of flattenedDocs) {
      const row = sortedCols.map((col) => {
        let val = fdoc[col] == null ? '' : fdoc[col];
        if (typeof val === 'object') {
          // if any object remains, convert to JSON string
          val = JSON.stringify(val);
        }
        // Escape double-quotes
        val = String(val).replace(/"/g, '""');
        // Wrap in quotes
        return `"${val}"`;
      });
      csv += row.join(',') + '\n';
    }

    // 5) Set headers so browser downloads as <collName>.csv
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${collName}.csv"`);
    res.send(csv);
  } catch (err) {
    console.error('Error exporting CSV:', err);
    res.status(500).json({ error: 'Failed to export CSV' });
  }
});

/**
 * GET /api/databases/:dbName/exportAll
 * - Exports all collections in the specified DB
 * - Returns a single ZIP file containing one CSV per collection
 */
app.get('/api/databases/:dbName/exportAll', async (req, res) => {
  const { dbName } = req.params;
  try {
    await client.connect();
    const db = client.db(dbName);

    // 1) Get all collections
    const collectionsInfo = await db.listCollections().toArray();
    const collections = collectionsInfo.map((c) => c.name);

    // 2) Create a ZIP in-memory using archiver
    const archive = archiver('zip', { zlib: { level: 9 } });
    
    // If you want the download to have a specific filename, set Content-Disposition, etc.
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${dbName}_all_collections.zip"`);

    // Pipe the archive data to the response
    archive.pipe(res);

    // 3) For each collection, build a CSV and append it to the archive
    for (const collName of collections) {
      const collection = db.collection(collName);
      const docs = await collection.find({}).toArray();

      // Flatten and collect all columns
      const flattenedDocs = [];
      const allColumns = new Set();
      for (const doc of docs) {
        const flat = flattenDoc(doc);
        flattenedDocs.push(flat);
        Object.keys(flat).forEach((k) => allColumns.add(k));
      }

      const sortedCols = Array.from(allColumns).sort();
      let csv = sortedCols.join(',') + '\n';

      for (const fdoc of flattenedDocs) {
        const row = sortedCols.map((col) => {
          let val = fdoc[col] == null ? '' : fdoc[col];
          if (typeof val === 'object') {
            val = JSON.stringify(val);
          }
          val = String(val).replace(/"/g, '""');
          return `"${val}"`;
        });
        csv += row.join(',') + '\n';
      }

      // 4) Append this CSV to the archive, naming it <collectionName>.csv
      archive.append(csv, { name: `${collName}.csv` });
    }

    // 5) Finalize (signals archiver that we’re done appending files)
    await archive.finalize();
  } catch (err) {
    console.error('Error exporting all collections:', err);
    res.status(500).json({ error: 'Failed to export all collections' });
  }
});

// Start up
app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
