package main

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"text/template"
	"time"

	"github.com/joho/godotenv"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type RequestData struct {
	Headers   map[string]string `json:"headers"`
	Data      map[string]string `json:"data"`
	Timestamp time.Time         `json:"timestamp"`
}

type DBManager struct {
	client *mongo.Client
}

// getDayWithSuffix returns day with proper suffix.
func getDayWithSuffix(day int) string {
	if day%100 == 11 || day%100 == 12 || day%100 == 13 {
		return strconv.Itoa(day) + "th"
	}
	switch day % 10 {
	case 1:
		return strconv.Itoa(day) + "st"
	case 2:
		return strconv.Itoa(day) + "nd"
	case 3:
		return strconv.Itoa(day) + "rd"
	default:
		return strconv.Itoa(day) + "th"
	}
}

// getDailyDBName constructs the daily database name.
func getDailyDBName(t time.Time) string {
	dayWithSuffix := getDayWithSuffix(t.Day())
	monthLower := strings.ToLower(t.Format("Jan"))
	return dayWithSuffix + "-" + monthLower
}

// getCurrentCollectionName returns the first "data_N" collection with less than 100k documents.
func (db *DBManager) getCurrentCollectionName(dbName string) (string, error) {
	for i := 1; i <= 1000; i++ {
		collName := fmt.Sprintf("data_%d", i)
		collection := db.client.Database(dbName).Collection(collName)

		count, err := collection.CountDocuments(context.Background(), bson.D{})
		if err != nil {
			return "", err
		}
		if count < 100000 {
			return collName, nil
		}
	}
	return "", errors.New("all daily collections are at capacity (over 10 million docs!)")
}

func NewDBManager(uri string) (*DBManager, error) {
	clientOptions := options.Client().ApplyURI(uri)
	client, err := mongo.Connect(context.Background(), clientOptions)
	if err != nil {
		return nil, err
	}
	if err := client.Ping(context.Background(), nil); err != nil {
		return nil, err
	}
	return &DBManager{client: client}, nil
}

// StoreRequest uses getCurrentCollectionName to pick the sub-collection and stores the request.
func (db *DBManager) StoreRequest(data RequestData) error {
	dbName := getDailyDBName(time.Now())
	collName, err := db.getCurrentCollectionName(dbName)
	if err != nil {
		return err
	}
	collection := db.client.Database(dbName).Collection(collName)
	_, err = collection.InsertOne(context.Background(), data)
	return err
}

// getDailyCollections lists all collections named "data_*" for the specified database.
func getDailyCollections(client *mongo.Client, dbName string) ([]string, error) {
	collNames, err := client.Database(dbName).ListCollectionNames(context.Background(), bson.D{})
	if err != nil {
		return nil, err
	}
	var results []string
	for _, c := range collNames {
		if strings.HasPrefix(c, "data_") {
			results = append(results, c)
		}
	}
	return results, nil
}

// shouldStoreRequest examines the request and returns false if it looks like a ping or preview.
func shouldStoreRequest(r *http.Request) bool {
	// If there are no query parameters, skip (to avoid health checks or simple pings).
	if r.URL.RawQuery == "" {
		return false
	}
	// Check the "Purpose" header (some browsers set this for prefetching/previewing).
	purpose := r.Header.Get("Purpose")
	if purpose == "preview" || purpose == "prefetch" {
		return false
	}
	// Optionally, filter out known monitoring user agents.
	userAgent := strings.ToLower(r.Header.Get("User-Agent"))
	if strings.Contains(userAgent, "pingdom") || strings.Contains(userAgent, "healthcheck") {
		return false
	}
	return true
}

// RequestHandler now only stores requests that pass the filtering defined by shouldStoreRequest.
func RequestHandler(db *DBManager) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		// Filter out unwanted requests.
		if !shouldStoreRequest(r) {
			w.WriteHeader(http.StatusNoContent)
			return
		}

		// Process query parameters.
		queryParams := r.URL.Query()
		data := make(map[string]string)
		for key, values := range queryParams {
			if len(values) > 0 {
				data[key] = values[0]
			}
		}
		// Also add current date.
		currentDate := time.Now().Format("2006-01-02")
		data["date"] = currentDate

		// Gather headers.
		headers := make(map[string]string)
		for key, values := range r.Header {
			if len(values) > 0 {
				headers[key] = values[0]
			}
		}

		requestData := RequestData{
			Headers:   headers,
			Data:      data,
			Timestamp: time.Now(),
		}

		if err := db.StoreRequest(requestData); err != nil {
			log.Printf("Error storing request: %v", err)
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		w.WriteHeader(http.StatusNoContent)
	}
}

func FrontendHandler(db *DBManager) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		dbName := getDailyDBName(time.Now())

		// Fetch all data_* collections for this day.
		collNames, err := getDailyCollections(db.client, dbName)
		if err != nil {
			http.Error(w, "Error listing collections", http.StatusInternalServerError)
			return
		}

		var allRequests []RequestData
		for _, cName := range collNames {
			collection := db.client.Database(dbName).Collection(cName)
			cursor, err := collection.Find(context.Background(), bson.D{})
			if err != nil {
				http.Error(w, "Error reading from MongoDB", http.StatusInternalServerError)
				return
			}
			var requests []RequestData
			if err := cursor.All(context.Background(), &requests); err != nil {
				http.Error(w, "Error parsing data", http.StatusInternalServerError)
				return
			}
			allRequests = append(allRequests, requests...)
		}

		tmpl := `<!DOCTYPE html>
<html>
<head>
    <title>Request Data</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background-color: #f2f2f2; text-align: left; }
    </style>
</head>
<body>
    <h1>Stored Request Data ({{.DBName}})</h1>
    <table>
        <tr>
            <th>Timestamp</th>
            <th>Headers</th>
            <th>Data</th>
        </tr>
        {{range .Requests}}
        <tr>
            <td>{{.Timestamp}}</td>
            <td>{{.Headers}}</td>
            <td>{{.Data}}</td>
        </tr>
        {{end}}
    </table>
</body>
</html>`

		dataForTemplate := struct {
			DBName   string
			Requests []RequestData
		}{
			DBName:   dbName,
			Requests: allRequests,
		}

		t := template.Must(template.New("frontend").Parse(tmpl))
		if err := t.Execute(w, dataForTemplate); err != nil {
			http.Error(w, "Template execution error", http.StatusInternalServerError)
		}
	}
}

func DownloadHandler(db *DBManager) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		format := r.URL.Query().Get("format")
		dbName := getDailyDBName(time.Now())

		// Fetch all data_* collections for this day.
		collNames, err := getDailyCollections(db.client, dbName)
		if err != nil {
			http.Error(w, "Error listing collections", http.StatusInternalServerError)
			return
		}

		var allRequests []RequestData
		for _, cName := range collNames {
			collection := db.client.Database(dbName).Collection(cName)
			cursor, err := collection.Find(context.Background(), bson.D{})
			if err != nil {
				http.Error(w, "Error reading from MongoDB", http.StatusInternalServerError)
				return
			}
			var requests []RequestData
			if err := cursor.All(context.Background(), &requests); err != nil {
				http.Error(w, "Error parsing data", http.StatusInternalServerError)
				return
			}
			allRequests = append(allRequests, requests...)
		}

		// Serve CSV vs JSON.
		if format == "csv" {
			w.Header().Set("Content-Type", "text/csv")
			w.Header().Set("Content-Disposition", "attachment; filename=request_data.csv")
			csvWriter := csv.NewWriter(w)
			defer csvWriter.Flush()

			// CSV header.
			csvWriter.Write([]string{"Timestamp", "HeaderKey", "HeaderValue", "DataKey", "DataValue"})

			// Write data.
			for _, req := range allRequests {
				for hKey, hValue := range req.Headers {
					for dKey, dValue := range req.Data {
						csvWriter.Write([]string{
							req.Timestamp.Format(time.RFC3339),
							hKey, hValue,
							dKey, dValue,
						})
					}
				}
			}
		} else {
			w.Header().Set("Content-Type", "application/json")
			w.Header().Set("Content-Disposition", "attachment; filename=request_data.json")
			json.NewEncoder(w).Encode(allRequests)
		}
	}
}

func main() {
	// Load environment variables from .env file
	err := godotenv.Load()
	if err != nil {
		log.Fatal("Error loading .env file")
	}
	// Retrieve MONGO_URL from the environment and initialize the DB
	mongoURL := os.Getenv("MONGO_URL")
	if mongoURL == "" {
		log.Fatal("MONGO_URL environment variable not set")
	}
	db, err := NewDBManager(mongoURL)
	if err != nil {
		log.Fatalf("Error initializing MongoDB: %v", err)
	}
	http.HandleFunc("/", RequestHandler(db))
	http.HandleFunc("/view", FrontendHandler(db))
	http.HandleFunc("/download", DownloadHandler(db))

	// Get the PORT from the environment, defaulting to 7000 if not set
	port := os.Getenv("PORT")
	if port == "" {
		port = "7000" // Default port if not provided in the environment
	}
	port = ":" + port // Format the port string for ListenAndServe
	log.Printf("Server starting on port %s", port)
	log.Fatal(http.ListenAndServe(port, nil))
}
