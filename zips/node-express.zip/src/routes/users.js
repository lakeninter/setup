const express = require("express");
const UserModel = require("../models/UserModal");
const router = express.Router();

// GET: Fetch all users
router.get("/", async (req, res) => {
  try {
    const users = await UserModel.find({});
    res.json(users);
  } catch (err) {
    console.log(err)
    res.status(500).json({ error: "Server error" });
  }
});

// POST: Create a new user
router.post("/", async (req, res) => {
  try {
    const newUser = new UserModel(req.body);
    const savedUser = await newUser.save();
    res.status(201).json(savedUser);
  } catch (err) {
    console.log(err)
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;
