import React from "react";
import Navbar from "./components/layouts/Navbar";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import UsersPage from "./pages/UserPage";

export default function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage/>} />
        <Route path="/users" element={<UsersPage/>} />
      </Routes>
    </BrowserRouter>
  );
}
