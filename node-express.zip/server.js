const express = require("express");
const cors = require("cors")
const { PORT } = require("./config");
const app = express();
const port = PORT;
const userRoute = require("./src/routes/users");
const dbConnect = require('./src/utils/dbConnect')

app.use(express.json());
app.use(cors());
app.use("/users", userRoute);

dbConnect();

app.get("/", (req, res) => {
  res.send("Server running!");
});

app.listen(port, () => {
  console.log(`Backend app listening on port http://localhost:${port}`);
});
