const mongoose = require("mongoose");
const { MONGO_URL } = require("../../config");

let cachedConnection = null;
const dbConnect = async () => {
  try {
    if (cachedConnection) return cachedConnection;
    const connection = await mongoose.connect(MONGO_URL);
    cachedConnection = connection;
    console.log("Mongodb connected successfully");
    return connection;
  } catch (error) {
    console.log("Fail to connect Mongodb");
  }
};
module.exports = dbConnect;
