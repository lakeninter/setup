const mongoose = require("mongoose");
const { MONGO_URL } = require("../../config");

let cachedConnection = null;
const dbConnect = async () => {
  console.log(MONGO_URL)
  try {
    if (cachedConnection) return cachedConnection;
    const connection = await mongoose.connect(MONGO_URL);
    cachedConnection = connection;
    console.log("Mongodb connected successfully");
    return connection;
  } catch (error) {
    console.log("Fail to connect Mongodb",error);
  }
};
module.exports = dbConnect;
