import React from 'react'
import ContactPage from '../components/ContactForm'

export default function HomePage() {
  return (
    <div className='bg-slate-100 min-h-screen'>
      <ContactPage/>
    </div>
  )
}
