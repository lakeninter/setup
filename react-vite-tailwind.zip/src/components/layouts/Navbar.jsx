import React, { useState } from "react";
import { Link } from "react-router-dom";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const toggleMenu = () => setIsOpen(!isOpen);

  return (
    <nav className="bg-gradient-to-r from-indigo-600 to-purple-600 shadow-lg">
      <div className="container mx-auto px-6 py-4 flex justify-start space-x-20 items-center">
        <Link to="/">
          <h1 className="text-3xl font-extrabold text-white tracking-wider hover:scale-105 transform transition duration-300">
            MyApp
          </h1>
        </Link>
        {/* Desktop Menu */}
        <ul className="hidden md:flex space-x-8">
          <li>
            <Link
              to="/"
              className="text-white text-lg font-medium hover:text-yellow-300 transition duration-300"
            >
              Home
            </Link>
          </li>
          <li>
            <Link
              to="/users"
              className="text-white text-lg font-medium hover:text-yellow-300 transition duration-300"
            >
              Users
            </Link>
          </li>
        </ul>
        {/* Mobile Menu Toggle */}
        <div className="md:hidden">
          <button
            onClick={toggleMenu}
            className="text-white focus:outline-none hover:text-yellow-300 transition duration-300"
            aria-label="Toggle navigation menu"
          >
            <svg className="h-8 w-8 fill-current" viewBox="0 0 24 24">
              {isOpen ? (
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M18.3 5.71a1 1 0 00-1.42-1.42L12 9.17 7.12 4.29A1 1 0 105.7 5.71L10.59 10.6 5.71 15.49a1 1 0 001.42 1.42L12 12.83l4.88 4.88a1 1 0 001.42-1.42L13.41 10.6l4.89-4.89z"
                />
              ) : (
                <path fillRule="evenodd" d="M4 5h16v2H4zm0 6h16v2H4zm0 6h16v2H4z" />
              )}
            </svg>
          </button>
        </div>
      </div>
      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-gradient-to-r from-indigo-600 to-purple-600">
          <ul className="px-2 pt-2 pb-3 space-y-2">
            <li>
              <Link
                to="/"
                onClick={() => setIsOpen(false)}
                className="block px-3 py-2 rounded-md text-lg font-medium text-white hover:bg-indigo-500 hover:text-yellow-300 transition duration-300"
              >
                Home
              </Link>
            </li>
            <li>
              <Link
                to="/users"
                onClick={() => setIsOpen(false)}
                className="block px-3 py-2 rounded-md text-lg font-medium text-white hover:bg-indigo-500 hover:text-yellow-300 transition duration-300"
              >
                Users
              </Link>
            </li>
          </ul>
        </div>
      )}
    </nav>
  );
}
