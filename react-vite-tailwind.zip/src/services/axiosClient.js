import axios from "axios";

// Create an Axios instance
const axiosClient = axios.create({
  baseURL: `${process.env.BASE_URL}:5000`,
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 10000, // Optional: Set a timeout for requests
});

// Optional: Add request interceptor
axiosClient.interceptors.request.use(
  (config) => {
    // Example: Attach token if you have authentication
    // const token = localStorage.getItem("token");
    // if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// Optional: Add response interceptor
axiosClient.interceptors.response.use(
  (response) => response,
  (error) => {
    // console.error("API Error:", error?.response ?? error?.message ?? error);
    return Promise.reject(error);
  }
);

export default axiosClient;
